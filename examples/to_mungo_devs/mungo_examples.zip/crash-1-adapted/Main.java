import java.util.function.Supplier;

public class Main {
  public static void main() {
    Supplier<String> fn = () -> {
      return "";
    };
  }
}
