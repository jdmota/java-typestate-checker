## Current Mungo's output

```

Wrapper.java: 6-15: Semantic Error
		Object reference is used uninitialised.```

