import mungo.lib.Typestate;

@Typestate("ObjProtocol")
public class Obj {

  public void finish() {

  }

}
