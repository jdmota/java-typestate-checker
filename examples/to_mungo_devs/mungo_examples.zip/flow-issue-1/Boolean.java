enum Boolean {
	True, False;
}
