import mungo.lib.Typestate;

@Typestate("FileProtocol")
class File {

  public String read() {
    return "";
  }

  public void close() {
  }

}
