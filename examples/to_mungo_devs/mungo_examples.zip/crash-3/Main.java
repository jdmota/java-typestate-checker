import java.util.*;

public class Main {
  public static void main() {
    List<File> list = new LinkedList<>();
    list.add(new File());
    File f1 = list.get(0);
  }
}
