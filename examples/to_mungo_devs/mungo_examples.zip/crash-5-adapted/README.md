## Current Mungo's output

```

Obj.java: 0-0: Semantic Error
		Cannot find typestate Obj defined for class Obj.

Obj.java: 0-0: Semantic Error
		Cannot find typestate Obj defined for class Obj.```

