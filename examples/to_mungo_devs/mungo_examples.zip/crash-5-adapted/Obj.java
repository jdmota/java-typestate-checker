import mungo.lib.Typestate;

@Typestate("Obj")
public class Obj {

  // private Obj f = null;

  public void finish() {

  }

}
