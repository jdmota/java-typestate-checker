class FileWrapper {
  public File file = new File();
}
