public enum FileStatus {
  OK, ERROR
}
