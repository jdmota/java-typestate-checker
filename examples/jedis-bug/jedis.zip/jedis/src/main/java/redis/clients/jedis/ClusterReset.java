package redis.clients.jedis;

public enum ClusterReset {
  SOFT, HARD
}
